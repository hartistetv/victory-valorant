<img width="150" height="150" align="left" style="float: left; margin: 0 10px 0 0;" alt="Alcatraz" src="https://i.imgur.com/cZkBm9I.png">  

# Alcatraz

[![](https://img.shields.io/discord/793143215057272892.svg?logo=discord&colorB=7289DA)](https://discord.com/invite/MYMAW3Ff53)
[![](https://img.shields.io/badge/discord.js-v12.0.0--dev-blue.svg?logo=npm)](https://discord.js.org/)
[![](https://img.shields.io/badge/paypal-donate-blue.svg)](https://paypal.me/alboomdon)
[![](https://www.codefactor.io/repository/gitlab/galackqsm/alcatraz/badge)](https://www.codefactor.io/repository/gitlab/galackqsm/Alcatraz)

> Ce bot est sous licence et également en open-source.

Alcatraz est un bot Discord codé en JavaScript avec [Discord.js](https://discord.js.org) et [SQLITE](https://www.sqlite.org).  
N'hésitez pas à ajouter une étoile ⭐ au référentiel pour promouvoir le projet!
## Informations

### Bot complet

Offres de Alcatraz:
* 💥 Un bot 100% Français pas comme les autres
* 💯 Plus de 120 commandes
* 🌐 Des commandes en tout genre, Rôle couleur, Fun, Nsfw, Modération, Général, Image etc...
* 🤩 Besoin que d'un bot au mieux de plusieurs
* ⚙️ Rejoins la communautés de Alcatraz Empire

### Les commandes

Alcatraz a beaucoup de fonctionnalités, avec **9 catégories principales**:

*   👩‍💼 **Administration**: `desacategorie`, `randomcolor`, `setautokick`, `setwelcomechannel`, `setwelcomemessage` et **+**! 
*   🚓 **Modération**: `addrole`, `slowmode`, `softban`, `warnlist`, et **+**! 
*   ⭐ **couleur**: `couleur`, `couleurhasard`, `creecouleur`, `creedefaultcolors`, et **+**! 
*   🎲 **Fun**: `clyde`, `blague`, `kiss`, `fakeban`, `trumptweet` et **+**! 
*   🖨️ **Général**: `bienvenue`, `feedback`, `pseudo`, et **+**! 
*   🔞 **Nsfw**: `4k`, `anal`, `gonewild`, `hentai`, `pgif` et **+**! 
*   🔔 **Info**: `admins`, `avatar`, `invitemoi`, `members`, `saloninfo` et **+**! 
*   🏆 **Points**: `actionpoints`, `couronne`, `givepoints`, `leaderboard`, `position` et **+**! 
*   👑 **Owner**: `delallservpoints`, `quitguild`, `servers`, `eval`, `deluserpoints` et **+**! 

## Installation
* 1- Commencer par télécharger le repo et d'extraire le dossier `alcatraz-main`sur votre bureau.
* 2- Ouvrez le dossier `alcatraz-main` et crée un dossier `data`.
* 3- Ouvrez la racine de votre dossier avec CMD
* 4- Faite la commande `npm install`, `npm install figlet`, et `npm install node-superfetch`.
* 5- Allez dans le fichier `config.jon` et le remplir.
* 6- Après faite dans le CMD `npm start`.

## Lien utiles

*   [Discord](https://discord.com/invite/MYMAW3Ff53)
*   [Github](https://github.com/ThisDudeBoy/Alcatraz/)

