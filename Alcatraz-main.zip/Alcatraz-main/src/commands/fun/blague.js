//  ______   __                      __                                  
// /      \ |  \                    |  \                                 
//|  $$$$$$\| $$  _______  ______  _| $$_     ______   ______   ________ 
//| $$__| $$| $$ /       \|      \|   $$ \   /      \ |      \ |        \
//| $$    $$| $$|  $$$$$$$ \$$$$$$\\$$$$$$  |  $$$$$$\ \$$$$$$\ \$$$$$$$$
//| $$$$$$$$| $$| $$      /      $$ | $$ __ | $$   \$$/      $$  /    $$ 
//| $$  | $$| $$| $$_____|  $$$$$$$ | $$|  \| $$     |  $$$$$$$ /  $$$$_ 
//| $$  | $$| $$ \$$     \\$$    $$  \$$  $$| $$      \$$    $$|  $$    \
// \$$   \$$ \$$  \$$$$$$$ \$$$$$$$   \$$$$  \$$       \$$$$$$$ \$$$$$$$$
//=======================================================================                                                                      
//● Crée par GalackQSM#0895 le 09 novembre 2020
//● Serveur Discord: https://discord.gg/HPtTfqDdMr
//● Github: https://github.com/GalackQSM/Alcatraz                                                  
//=======================================================================                                                                      
                                                                       
const Command = require('../Alcatraz.js');
const Discord = require("discord.js");
const { MessageEmbed } = require('discord.js');
const fetch = require("node-fetch");


module.exports = class Joke extends Command {

  constructor (client) {
    super(client, {
      name: 'blague',
      aliases: ['joke'],
      usage: 'blague',
      description: 'Trouver une blague au hasard',
      type: client.types.FUN
    });
  }

  async run (message, args, data) {

    {
        var headers = { Authorization: "PHKgOQejoFh7ipfmOrzji9sRJkOEDd28M0IY6-klwjFojtkMFtfirTl.d4a3.Z--" }
        fetch('https://blague.xyz/api/joke/random/', { headers: headers }  )
        .then(rep => rep.json() )
        .then(json => {
        let random = new MessageEmbed()
        .setTitle(""+message.author.username+" voici une blague pour vous.")
        .setFooter("© 2020 - Alcatraz | Projet open-source")
        .setTimestamp()
        .setColor("#2f3136")
        .setDescription(`**__Blague:__** ${json.joke["question"]}\n**__Réponse:__** ||${json.joke["answer"]}||`)
            message.channel.send(random);

        })

    }

  }

};